<script setup>

</script>

<template>
    <svg
        id="bin_26"
        data-name="Group 26"
        xmlns="http://www.w3.org/2000/svg"
        width="21.147"
        height="21.147"
        viewBox="0 0 21.147 21.147"
    >
        <g
            id="Ellipse_2"
            data-name="Ellipse 2"
            transform="translate(0 0)"
            fill="none"
            stroke="#fff"
            stroke-width="2.2"
        >
            <circle cx="7.837" cy="7.837" r="7.837" stroke="none"/>
            <circle cx="7.837" cy="7.837" r="6.737" fill="none"/>
        </g>
        <line
            id="Line_3"
            data-name="Line 3"
            x2="5.878"
            y2="5.878"
            transform="translate(13.714 13.714)"
            fill="none"
            stroke="#fff"
            stroke-linecap="round"
            stroke-width="2.2"
        />
    </svg>
</template>
