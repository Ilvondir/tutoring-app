<script setup>

</script>

<template>
    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"
         viewBox="0 0 28 28">
        <g id="bin_1237" data-name="Group 1237"
           transform="translate(-227.643 342.492)">
            <path id="Path_1190" data-name="Path 1190"
                  d="M253.643-314.492h-24a2,2,0,0,1-2-2v-24a2,2,0,0,1,2-2h24a2,2,0,0,1,2,2v24A2,2,0,0,1,253.643-314.492Zm-24-27a1,1,0,0,0-1,1v24a1,1,0,0,0,1,1h24a1,1,0,0,0,1-1v-24a1,1,0,0,0-1-1Z"
                  fill="#4F46E5"/>
            <g id="bin_1236" data-name="Group 1236"
               transform="translate(232.553 -337.582)">
                <path id="Path_1191" data-name="Path 1191"
                      d="M271.84-306.35a8.065,8.065,0,0,1,8.055,8.055,8.065,8.065,0,0,1-8.055,8.055,8.064,8.064,0,0,1-8.055-8.055,8.064,8.064,0,0,1,8.055-8.055m0-1.035a9.09,9.09,0,0,0-9.09,9.09,9.09,9.09,0,0,0,9.09,9.09,9.09,9.09,0,0,0,9.09-9.09,9.09,9.09,0,0,0-9.09-9.09Z"
                      transform="translate(-262.75 307.385)" fill="#4F46E5"/>
                <rect id="Rectangle_220" data-name="Rectangle 220" width="2.356"
                      height="2.356" rx="0.6" transform="translate(7.912 4.073)"
                      fill="#4F46E5"/>
                <rect id="Rectangle_221" data-name="Rectangle 221" width="2.356"
                      height="6.009" rx="0.6" transform="translate(7.912 8.099)"
                      fill="#4F46E5"/>
            </g>
        </g>
    </svg>
</template>

<style scoped>

</style>
