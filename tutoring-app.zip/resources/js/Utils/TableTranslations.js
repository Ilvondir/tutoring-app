export default {
    pagingInfo: 'Wyświetlono {0}-{1} z {2}',
    pageSizeChangeLabel: "Liczba wierszy:",
    gotoPageLabel: "Strona:",
    noDataAvailable: "Brak danych",
}
